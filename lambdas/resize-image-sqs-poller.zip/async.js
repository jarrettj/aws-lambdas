'use strict';
// dependencies
var async = require('async');
var fs = require("fs");
//async.concat(['dr', 'ds'], callSQS, function(err, files) {
//    // files is now a list of filenames that exist in the 3 directories
//    console.log(err);
//    console.log(files);
//});

//async.concat(['env','env','env'], fs.readdir, function(err, files) {
//    // files is now a list of filenames that exist in the 3 directories
//    console.log(files)
//    console.log(err)
//});

var calls = new Array(2);
async.concat(calls, callSQS, function(err, responses) {
    // files is now a list of filenames that exist in the 3 directories
    console.log(responses);
//    console.log(err)
});

function callSQS(item, callback) 
{
    
    console.log(item);
    callback(null, item);
//    return {'yes'};
//    return [];
//    return ['yes'];
}